Saunter is an opinionated automation framework for use with the Selenium RC and WebDriver libraries. It is designed to remove a lot of the overhead and cruft that hinders teams when they first start out with automation. For documentation around Saunter see http://element34.ca/products/saunter.

Note: The configuration structure changed with 2.0.0. Either pin your install to the old version of click above link for a brief description of the change. In a nutshell, .ini has been replaced with .yaml.
