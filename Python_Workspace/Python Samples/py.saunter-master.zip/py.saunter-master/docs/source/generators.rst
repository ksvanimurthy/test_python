saunter.generators
================== 

Generators are useful for creating data on the fly.

.. automodule:: saunter.generators.string_data
  :members: