saunter.testcase.base
=====================

You likely do not want your scripts to inherit from this class directly. Instead, subclass it in your project and use that instead.

.. automodule:: saunter.testcase.base
  :members: BaseTestCase