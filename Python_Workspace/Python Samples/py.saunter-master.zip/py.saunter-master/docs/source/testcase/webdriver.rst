saunter.testcase.webdriver
==========================

You likely do not want your scripts to inherit from this class directly. Instead, subclass it in your project and use that instead.

.. automodule:: saunter.testcase.webdriver
  :members: SaunterTestCase