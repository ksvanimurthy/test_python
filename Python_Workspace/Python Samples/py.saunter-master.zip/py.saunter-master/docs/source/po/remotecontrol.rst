Pages
=====

.. automodule:: saunter.po.remotecontrol.page
  :members: Page

Elements
========
  
.. automodule:: saunter.po.remotecontrol.element
  :members: Element
  
.. automodule:: saunter.po.remotecontrol.checkbox
  :members: Checkbox
  
.. automodule:: saunter.po.remotecontrol.select
  :members: Select
  
.. automodule:: saunter.po.remotecontrol.text
  :members: Text  