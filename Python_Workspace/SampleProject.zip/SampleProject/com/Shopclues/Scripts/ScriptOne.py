from com.Shopclues.Library.BaseLib import *
class BuyShirt(Intialization):
    def test_men_denim(self):
        if not self.driver.find_element_by_name(self, 'Popular Categories').is_displayed() :
            self.driver._switch_to
